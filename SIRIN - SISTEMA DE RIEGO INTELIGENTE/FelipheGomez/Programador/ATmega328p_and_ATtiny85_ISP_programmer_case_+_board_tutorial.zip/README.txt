                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2152358
ATmega328p and ATtiny85 ISP programmer case + board tutorial by alojz is licensed under the GNU - GPL license.
http://creativecommons.org/licenses/GPL/2.0/

# Summary

### Why this?
This is a case for my programmer breakout board I made because i got tired of using breadboards to program my chips. :) Nice weekend project.

### Updates
*2017.03.04:*
Now with a button and a switch

*2017.03.05:*
Tutorial! scroll down

*2017.03.06: *
Additional tray (optional expansion) to store your chips, some nuts and bolts.
What a coincidence! ATmega328 fits really tight left to right, I repeat, I did NOT measure the chip before designing the tray! :D

###Other projects
*Tamaguino*
http://www.thingiverse.com/thing:2120692
https://alojzjakob.github.io/Tamaguino/

*Website traffic / Like monitor with NodeMcu*
http://www.thingiverse.com/thing:2286288


# Print Settings

Printer Brand: Wanhao
Printer: Wanhao Duplicator i3 V2
Rafts: Doesn't Matter
Supports: Doesn't Matter
Resolution: 0.1
Infill: 50